module com.example.finalprojectsoftware {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;
    requires com.google.zxing;
    requires java.desktop;

    opens com.example.finalprojectsoftware to javafx.fxml;
    exports com.example.finalprojectsoftware;
}