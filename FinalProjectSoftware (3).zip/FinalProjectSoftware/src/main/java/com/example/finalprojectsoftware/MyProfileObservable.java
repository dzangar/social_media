package com.example.finalprojectsoftware;

public interface MyProfileObservable {
    void addObserver(MyProfileObserver observer);
    void removeObserver(MyProfileObserver observer);
    void notifyObservers();
}
