package com.example.finalprojectsoftware;

public class ClickedUser {
    private static String clicked;
    public static void setClicked(String user) {
        clicked= user;
    }
    public static String getClicked() {
        return clicked;
    }
}
