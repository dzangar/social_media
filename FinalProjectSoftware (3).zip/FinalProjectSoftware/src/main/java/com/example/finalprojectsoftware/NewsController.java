package com.example.finalprojectsoftware;

import javafx.animation.PauseTransition;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.IOException;
import java.net.*;
import java.sql.*;

public class NewsController {
    String username=getLoggedInUser();
    @FXML
    private VBox vbox;
    @FXML
    private VBox commentListVBOX;

    @FXML
    private AnchorPane commentPane;

    @FXML
    private ImageView x;
    private NewsAgency newsAgency;
    private ClientThreadForNews clientThreadForNews;
    private DatagramSocket socket;

    private InetAddress address;

    public NewsController() throws UnknownHostException, SocketException {
        socket = new DatagramSocket();
        address = InetAddress.getByName("localhost");
    }

    @FXML
    void initialize() throws IOException {
        vbox.getChildren().clear();
        DB.loadNews(vbox,commentPane,commentListVBOX,scrollPaneComment);
        // Создаем NewsAgency и регистрируем его в качестве субъекта
        newsAgency = new NewsAgency();

        // Создаем ClientThreadForNews и передаем ему все необходимые параметры
        clientThreadForNews = new ClientThreadForNews(socket, newsAgency,vbox,commentPane,commentListVBOX,scrollPaneComment);
        byte[] uuid = ("init;" + Logged.getLoggedInUser()).getBytes();
        DatagramPacket initialize = new DatagramPacket(uuid, uuid.length, address, Server.PORT);
        socket.send(initialize);

        // Инициализация и запуск потока
        clientThreadForNews.start();
    }
    @FXML
    void x(MouseEvent event) {
        commentPane.setVisible(false);
    }

    @FXML
    void friends(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("friends.fxml"));

        Scene newScene = new Scene(root);

        Stage stage = (Stage) ((Node)event.getSource()).getScene().getWindow();

        stage.setScene(newScene);

        stage.show();
    }

    @FXML
    void messages(ActionEvent event) throws IOException {

        Parent root = FXMLLoader.load(getClass().getResource("messages.fxml"));

        Scene newScene = new Scene(root);

        Stage stage = (Stage) ((Node)event.getSource()).getScene().getWindow();

        stage.setScene(newScene);

        stage.show();
    }

    @FXML
    void myprofile(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("myProfile.fxml"));

        Scene newScene = new Scene(root);

        Stage stage = (Stage) ((Node)event.getSource()).getScene().getWindow();

        stage.setScene(newScene);

        stage.show();
    }
    @FXML
    private TextField commentTF;

    @FXML
    private ScrollPane scrollPaneComment;

    @FXML
    void news(ActionEvent event) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("news.fxml"));

        Scene newScene = new Scene(root);

        Stage stage = (Stage) ((Node)event.getSource()).getScene().getWindow();

        stage.setScene(newScene);

        stage.show();
    }

    @FXML
    void search(ActionEvent event) {

    }
    @FXML
    private TextField searchTextField;
    @FXML
    void searchButton(MouseEvent event) throws IOException {
        DB.search(searchTextField,event);
    }
    @FXML
    void sendComment(MouseEvent event) throws SQLException {
        DB.insertIntoComment(commentTF);
        VBox v = new VBox();
        AnchorPane anchorPane = new AnchorPane();
        anchorPane.setMinSize(360, 1);
        anchorPane.setMaxSize(360, 1);
        anchorPane.setPadding(new Insets(0,0,0,10));
        anchorPane.setStyle("-fx-background-color: black;");
        v.getChildren().add(anchorPane);
        Text username = new Text(Logged.getLoggedInUser());

        TextFlow users = new TextFlow(username);
        users.setStyle("-fx-font-size: 25; -fx-font-weight: bold;");
        users.setPadding(new Insets(0, 0, 0, 5));
        v.getChildren().add(users);
        Text texts = new Text(commentTF.getText());

        TextFlow txt = new TextFlow(texts);
        txt.setStyle("-fx-font-size: 15;");
        txt.setPadding(new Insets(0, 0, 0, 5));
        v.getChildren().add(txt);
        AnchorPane anchorPane1 = new AnchorPane();
        anchorPane1.setMinSize(360, 1);
        anchorPane1.setMaxSize(360, 1);
        anchorPane1.setStyle("-fx-background-color: black;");
        v.getChildren().add(anchorPane1);
        scrollPaneComment.setVvalue(1.0);
        Platform.runLater(() -> {
            // Allow JavaFX to perform layout and rendering
            PauseTransition pause = new PauseTransition(Duration.millis(50));
            pause.setOnFinished(e -> {
                // Scroll to the bottom of the VBox
                commentListVBOX.layout();
                scrollPaneComment.setVvalue(1.0);
            });
            pause.play();
        });
        commentListVBOX.getChildren().add(v);
        commentTF.setText("");
    }
    private static String loggedInUser;
    public static void setLoggedInUser(String user) {
        loggedInUser = user;
    }
    public static String getLoggedInUser() {
        return loggedInUser;
    }


}
