package com.example.finalprojectsoftware;

import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;

// Лист для отдельного друга
public class FriendLeaf implements FriendComponent {
    private String username;

    public FriendLeaf(String username) {
        this.username = username;
    }

    @Override
    public void display(VBox container) {
        VBox v = new VBox();
        v.setStyle("-fx-background-color: #e9d787; -fx-background-radius: 30; -fx-padding: 0 15 0 15;");
        Label us = new Label();
        us.setStyle("-fx-font-size: 19; -fx-font-weight: bold;");
        us.setText(username);
        v.getChildren().add(us);
        v.setMinSize(715, 53);
        v.setMaxSize(715, 53);
        v.setAlignment(Pos.CENTER_LEFT);
        container.getChildren().add(v);
        v.setOnMouseClicked(e -> {
            ClickedUser.setClicked(us.getText());
            Parent root = null;
            try {
                root = FXMLLoader.load(getClass().getResource("Profile.fxml"));
                Scene newScene = new Scene(root);

                Stage stage = (Stage) ((Node) e.getSource()).getScene().getWindow();

                stage.setScene(newScene);
                stage.show();
                System.out.println(us.getText());
            } catch (IOException ex) {
                throw new RuntimeException(ex);
            }
        });
    }
}
