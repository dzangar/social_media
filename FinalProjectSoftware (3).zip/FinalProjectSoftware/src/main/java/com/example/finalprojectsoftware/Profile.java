package com.example.finalprojectsoftware;

import java.util.ArrayList;
import java.util.List;

public // Класс, который представляет профиль
class Profile implements MyProfileObservable {
    private List<MyProfileObserver> observers = new ArrayList<>();

    // Другие поля и методы профиля

    @Override
    public void addObserver(MyProfileObserver observer) {
        observers.add(observer);
    }

    @Override
    public void removeObserver(MyProfileObserver observer) {
        observers.remove(observer);
    }

    @Override
    public void notifyObservers() {
        for (MyProfileObserver observer : observers) {
            observer.update();
        }
    }

    // Метод, который вызывается при событии, например, нажатии на QR
    public void onQRCodeClicked() {
        // Логика обработки события
        // ...

        // Уведомление наблюдателей об изменении
        notifyObservers();
    }

    // Другие методы, которые изменяют состояние профиля
}