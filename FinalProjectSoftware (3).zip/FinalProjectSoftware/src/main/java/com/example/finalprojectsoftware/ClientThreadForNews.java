package com.example.finalprojectsoftware;

import javafx.animation.PauseTransition;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;
import javafx.util.Duration;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

public class ClientThreadForNews extends Thread implements NewsObserver{
    private static int w;
    private DatagramSocket socket;
    private NewsSubject newsSubject;
    private byte[] incoming = new byte[256];
    private VBox vbox;
    private AnchorPane commentPane;
    private VBox commentListVBOX;
    private ScrollPane scrollPaneComment;

    public ClientThreadForNews(DatagramSocket socket, NewsSubject newsSubject) {
        this.socket = socket;
        this.newsSubject = newsSubject;
        newsSubject.addObserver(this);
    }

    public ClientThreadForNews(DatagramSocket socket, NewsSubject newsSubject, VBox vbox, AnchorPane commentPane, VBox commentListVBOX, ScrollPane scrollPaneComment) {
        this.socket = socket;
        this.newsSubject = newsSubject;
        this.vbox = vbox;
        this.commentPane = commentPane;
        this.commentListVBOX = commentListVBOX;
        this.scrollPaneComment = scrollPaneComment;
        newsSubject.addObserver(this);
    }
    private static int wallId;
    public static void setWallId(int w) {
        wallId = w;
    }


    @Override
    public void run() {
        System.out.println("starting thread");
        while (true) {
            DatagramPacket packet = new DatagramPacket(incoming, incoming.length);
            try {
                socket.receive(packet);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            System.out.println("work 2");
            String message = new String(packet.getData(), 0, packet.getLength());
            System.out.println(message);

            // Добавим уведомление NewsSubject о новой новости
            if (newsSubject != null) {
                newsSubject.notifyObservers(message);

                // Create an instance of NewsReader and start it
//                NewsReader newsReader = new NewsReader("Reader1"); // You can pass the desired name
//                newsReader.start();
            }
        }
    }

    @Override
    public void update(String news) {
        Platform.runLater(() -> {
            // Обновление интерфейса на основе новости
            // Вставьте ваш код обновления интерфейса здесь
            String[] parts = news.split(":");
            String type = parts[0].trim();
            if(type.equals("news")){
                System.out.println("ClientThreadForNews получил новость: " + news);
                String senderName = parts[1].trim();
                String newsContent = parts[2].trim();
                int receivedWallId = Integer.parseInt(parts[3].trim());
                VBox v = new VBox();
                AnchorPane anchorPane = new AnchorPane();
                anchorPane.setMinSize(700, 1);
                anchorPane.setMaxSize(700, 1);
                anchorPane.setStyle("-fx-background-color: black;");
                v.getChildren().add(anchorPane);
                Text username = new Text(senderName);
                TextFlow users = new TextFlow(username);
                users.setStyle("-fx-font-size: 25; -fx-font-weight: bold;");
                users.setPadding(new Insets(0, 0, 0, 5));
                v.getChildren().add(users);
                Text texts = new Text(newsContent);
                TextFlow txt = new TextFlow(texts);
                txt.setStyle("-fx-font-size: 15;");
                txt.setPadding(new Insets(0, 0, 0, 10));
                v.getChildren().add(txt);
                HBox hBox = new HBox();
                ImageView like = new ImageView(new Image("C:\\Users\\dzang\\IdeaProjects\\FinalProjectSoftware\\src\\main\\resources\\com\\example\\finalprojectsoftware\\love.png"));
                like.setFitWidth(31);
                like.setFitHeight(37);
                ImageView comment = new ImageView(new Image("C:\\Users\\dzang\\IdeaProjects\\FinalProjectSoftware\\src\\main\\resources\\com\\example\\finalprojectsoftware\\chat.png"));
                comment.setFitWidth(41);
                comment.setFitHeight(45);
                hBox.getChildren().addAll(like, comment);
                hBox.setAlignment(Pos.CENTER_LEFT);
                v.getChildren().add(hBox);
                AnchorPane anchorPane1 = new AnchorPane();
                anchorPane1.setMinSize(700, 1);
                anchorPane1.setMaxSize(700, 1);
                anchorPane1.setStyle("-fx-background-color: black;");
                v.getChildren().add(anchorPane1);
                vbox.getChildren().add(0, v);
                like.setPickOnBounds(true);
                comment.setPickOnBounds(true);
                AtomicBoolean checkLike = new AtomicBoolean(false);
                if (checkLike.get()) {
                    like.setImage(new Image("C:\\Users\\dzang\\IdeaProjects\\FinalProjectSoftware\\src\\main\\resources\\com\\example\\finalprojectsoftware\\heart (1).png"));
                } else {
                    like.setImage(new Image("C:\\Users\\dzang\\IdeaProjects\\FinalProjectSoftware\\src\\main\\resources\\com\\example\\finalprojectsoftware\\love.png"));
                }
                texts.setOnMouseClicked(eevent -> {
                    System.out.println("clicked");
                });
                like.setOnMouseClicked(e -> {
                    System.out.println("like");
                    if (!checkLike.get()) {
                        like.setImage(new Image("C:\\Users\\dzang\\IdeaProjects\\FinalProjectSoftware\\src\\main\\resources\\com\\example\\finalprojectsoftware\\heart (1).png"));
                        checkLike.set(true);
                        try {
                            DB.insertIntoLike(receivedWallId);
                        } catch (SQLException ex) {
                            throw new RuntimeException(ex);
                        }
                    } else {
                        like.setImage(new Image("C:\\Users\\dzang\\IdeaProjects\\FinalProjectSoftware\\src\\main\\resources\\com\\example\\finalprojectsoftware\\love.png"));
                        checkLike.set(false);
                        DB.deleteFromLike(receivedWallId);
                    }
                });
                System.out.println("Before comment.setOnMouseClicked: " + receivedWallId);
                comment.setOnMouseClicked(e -> {
                    DB.setWall(receivedWallId);
                    DB.commentLogicAndDesign(receivedWallId, commentListVBOX);
                    commentPane.setVisible(true);
                    System.out.println("walling" + receivedWallId);
                });
            }
        });
    }
}
