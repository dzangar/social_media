package com.example.finalprojectsoftware;

import java.util.List;

public interface FriendsObserver {
    void update(List<FriendComponent> friendsList);
}
