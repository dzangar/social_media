package com.example.finalprojectsoftware;

import java.util.ArrayList;
import java.util.List;

class NewsAgency implements NewsSubject {
    private List<NewsObserver> observers = new ArrayList<>();

    @Override
    public void addObserver(NewsObserver observer) {
        observers.add(observer);
    }

    @Override
    public void removeObserver(NewsObserver observer) {
        observers.remove(observer);
    }

    @Override
    public void notifyObservers(String news) {
        for (NewsObserver observer : observers) {
            observer.update(news);
        }
    }
}
