package com.example.finalprojectsoftware;

import javafx.scene.control.ScrollPane;
import javafx.scene.layout.VBox;

import java.util.List;

public interface MessageObserver {
    void update(String message);

    void setListVBox(VBox listvbox);

    void setScrollPane(ScrollPane scrollpane);

    void setListMessages(List<VBox> messages);
}
