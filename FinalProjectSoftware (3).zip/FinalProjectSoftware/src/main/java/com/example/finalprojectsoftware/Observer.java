package com.example.finalprojectsoftware;

import java.util.Observable;

public interface Observer  {


    void update(String message);
}