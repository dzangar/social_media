package com.example.finalprojectsoftware;

import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;

import java.util.ArrayList;
import java.util.List;

//public class UpdateUICommandAdapter implements Observer {
//
//    private VBox messageContainer; // Assuming you have a container for messages
//
//    public UpdateUICommandAdapter(VBox messageContainer) {
//        this.messageContainer = messageContainer;
//    }
//
//    @Override
//    public void update(String message) {
//        Platform.runLater(() -> {
//            // Update UI components based on the received message
//            HBox hBox = new HBox();
//            hBox.setAlignment(Pos.CENTER_LEFT);
//            hBox.setPadding(new Insets(5, 5, 5, 10));
//            Text textUser = new Text(message);
//            TextFlow textFlow = new TextFlow(textUser);
//            textFlow.setStyle("-fx-background-color: rgb(233,233,235); -fx-background-radius: 20px;");
//            textFlow.setPadding(new Insets(5, 10, 5, 10));
//            hBox.getChildren().add(textFlow);
//            messageContainer.getChildren().add(hBox);
//        });
//    }
//}
//
public class UpdateUICommandAdapter implements Command {
    private RawMessage rawMessage;
    private VBox listvbox;
    private ScrollPane scrollpane;

    public UpdateUICommandAdapter(RawMessage rawMessage, VBox listvbox, ScrollPane scrollpane) {
        this.rawMessage = rawMessage;
        this.listvbox = listvbox;
        this.scrollpane = scrollpane;
    }

    @Override
    public void execute() {
        String adaptedMessage = rawMessage.adapt();
        UpdateUICommand updateUICommand = new UpdateUICommand(new UIReceiver(listvbox,scrollpane), adaptedMessage);
        System.out.println(adaptedMessage);
        updateUICommand.execute();
    }
}


class RawMessage {
    private String content;
    private String fromUser;
    private String toUser;

    public RawMessage(String content) {
        this.content = content;
    }

    public RawMessage(String message, String fromUser, String toUser) {
        this.content=message;
        this.fromUser = fromUser;
        this.toUser = toUser;
    }

    public String getContent() {
        return content;
    }

    public String getFromUser() {
        return fromUser;
    }

    public String getToUser() {
        return toUser;
    }

    public String adapt() {
        // Ваш код для адаптации сообщения
        // Например, просто возвращаем содержимое сообщения
        return content;
    }
}
class UpdateUICommandAdapterForPage implements Command {
    private RawMessage rawMessage;
    private VBox listvbox;
    private ScrollPane scrollpane;
    private List<VBox> messages;

    public UpdateUICommandAdapterForPage(RawMessage rawMessage, VBox listvbox, ScrollPane scrollpane,List<VBox> messages) {
        this.rawMessage = rawMessage;
        this.listvbox = listvbox;
        this.scrollpane = scrollpane;
        this.messages = messages;
    }

    @Override
    public void execute() {
        String adaptedMessage = rawMessage.adapt();
        UpdateUICommandForPage updateUICommand = new UpdateUICommandForPage(new UIReceiverForPage(listvbox,scrollpane,messages), adaptedMessage,rawMessage.getFromUser(),rawMessage.getToUser());
        System.out.println(adaptedMessage);
        updateUICommand.execute();
    }
}