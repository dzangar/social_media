package com.example.finalprojectsoftware;

import javafx.animation.PauseTransition;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;
import javafx.util.Duration;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.util.ArrayList;
import java.util.List;

import javafx.animation.PauseTransition;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;
import javafx.util.Duration;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.util.*;

public class ClientThread extends Thread implements Subject{
    private DatagramSocket socket;
    private List<MessageObserver> observers = new ArrayList<>();

    public ClientThread(DatagramSocket socket, VBox listvbox, ScrollPane scrollpane) {
        this.socket = socket;
        this.listvbox = listvbox;
        this.scrollpane = scrollpane;
    }


    @Override
    public void addObserver(MessageObserver observer) {
        observers.remove(observer);
        observers.add(observer);
    }

    @Override
    public void removeObserver(MessageObserver observer) {
        observers.remove(observer);
    }
    VBox listvbox;
    ScrollPane scrollpane;
    @Override
    public void notifyObservers(String message) {
        System.out.println("Notifying observers");
        for (MessageObserver observer : observers) {
            observer.setListVBox(listvbox);
            observer.setScrollPane(scrollpane);
            observer.update(message);
        }
        System.out.println("Finished notifying observers");
    }

    @Override
    public void run() {
        byte[] buffer = new byte[256];
        DatagramPacket packet = new DatagramPacket(buffer, buffer.length);

        try {
            while (true) {
                socket.receive(packet);
                String message = new String(packet.getData(), 0, packet.getLength());
                System.out.println("our " +message);
                notifyObservers(message);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
class ChatController implements MessageObserver {
    private VBox listvbox;
    private ScrollPane scrollpane;
    private UpdateUICommand updateUICommand;
    private UpdateUICommandAdapter updateUICommandAdapter;
    private RawMessage rawMessage;


    @Override
    public void update(String message) {
        // Логика обновления интерфейса или другие операции при изменении состояния
        System.out.println("Received a new message: " + message);
        // Допустим, здесь происходит обновление чата с новым сообщением
        String fromUser = message.substring(0, message.indexOf(' '));
        String toUser = message.substring(message.indexOf(' ') + 1, message.indexOf(':'));
        message = message.substring(message.indexOf(':') + 2);
        rawMessage=new RawMessage(message);
        if(toUser        //touser     admin users: hello
                            .equals(MessagesWithUserContoller.getLoggedInUser()) &&
                            fromUser.equals(MessagesWithUserContoller.getUserInUser())) {
                updateUICommandAdapter = new UpdateUICommandAdapter(rawMessage, listvbox, scrollpane);
                updateUICommandAdapter.execute();
        }
        System.out.println("update");
    }

    @Override
    public void setListVBox(VBox listvbox) {
        this.listvbox=listvbox;
    }

    @Override
    public void setScrollPane(ScrollPane scrollpane) {
        this.scrollpane=scrollpane;
    }

    @Override
    public void setListMessages(List<VBox> messages) {

    }
}
// Concrete Command
class UpdateUICommand implements Command {
    private UIReceiver receiver;
    private String message;

    public UpdateUICommand(UIReceiver receiver, String message) {
        this.receiver = receiver;
        this.message = message;
    }

    @Override
    public void execute() {
        receiver.processMessage(message);
    }
}

// Receiver
class UIReceiver {
    private VBox listVBox;
    private ScrollPane scrollPane;

    public UIReceiver(VBox listVBox, ScrollPane scrollPane) {
        this.listVBox = listVBox;
        this.scrollPane = scrollPane;
    }

    public void processMessage(String message) {
        System.out.println("siksi");
        HBox hBox = new HBox();
        hBox.setAlignment(Pos.CENTER_LEFT);
        hBox.setPadding(new Insets(5, 5, 5, 10));
        Text textUser = new Text(message);
        TextFlow textFlow = new TextFlow(textUser);
        textFlow.setStyle("-fx-background-color: rgb(233,233,235); -fx-background-radius: 20px;");
        textFlow.setPadding(new Insets(5, 10, 5, 10));
        hBox.getChildren().add(textFlow);

        if (listVBox != null) {
            Platform.runLater(() -> {
                listVBox.getChildren().add(hBox);
            });
        } else {
            System.err.println("Error: listVBox is null");
        }

        scrollPane.setVvalue(1.0);
        Platform.runLater(() -> {
            PauseTransition pause = new PauseTransition(Duration.millis(50));
            pause.setOnFinished(e -> {
                listVBox.layout();
                scrollPane.setVvalue(1.0);
            });
            pause.play();
        });
    }
}