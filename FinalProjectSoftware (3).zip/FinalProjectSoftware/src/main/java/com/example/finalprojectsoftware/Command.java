package com.example.finalprojectsoftware;

public interface Command {
    void execute();
}
