package com.example.finalprojectsoftware;

public interface ProfileObserver {
    void update();
}