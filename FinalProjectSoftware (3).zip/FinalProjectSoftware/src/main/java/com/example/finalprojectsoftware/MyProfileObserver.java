package com.example.finalprojectsoftware;

public interface MyProfileObserver {
    void update();
}
