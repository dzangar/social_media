package com.example.finalprojectsoftware;

import javafx.animation.PauseTransition;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.IOException;
import java.sql.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

public class DB {
    private static final String DB_URL = "jdbc:postgresql://localhost:5432/a";
    private static final String DB_USER = "postgres";
    private static final String DB_PASSWORD = "root";

    public static void loadFriends(VBox vbox, String username) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            // Установление соединения с базой данных
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            // SQL-запрос SELECT
            String sql = "select friend1_id,friend2_id,friendship_status from friendship where friend1_id='" + username + "' and friendship_status='accept' or friend2_id='" + username + "' and friendship_status='accept'";
            preparedStatement = connection.prepareStatement(sql);
            resultSet = preparedStatement.executeQuery();  // Вызов executeQuery() перед использованием resultSet
            while (resultSet.next()) {
                String user1 = resultSet.getString("friend1_id");
                String user2 = resultSet.getString("friend2_id");
                String status = resultSet.getString("friendship_status");
                VBox v = new VBox();
                v.setStyle("-fx-background-color: #e9d787; -fx-background-radius: 30; -fx-padding: 0 15 0 15;");
                Label us = new Label();
                us.setStyle("-fx-font-size: 19; -fx-font-weight: bold;");
                if (user1.equals(Logged.getLoggedInUser())) {
                    us.setText(user2);
                } else if (user2.equals(Logged.getLoggedInUser())) {
                    us.setText(user1);
                }
                v.getChildren().add(us);
                v.setMinSize(715, 53);
                v.setMaxSize(715, 53);
                v.setAlignment(Pos.CENTER_LEFT);
                vbox.getChildren().add(v);
                v.setOnMouseClicked(e -> {
                    ClickedUser.setClicked(us.getText());
                    Parent root = null;
                    try {
                        root = FXMLLoader.load(DB.class.getResource("Profile.fxml"));
                        Scene newScene = new Scene(root);

                        Stage stage = (Stage) ((Node) e.getSource()).getScene().getWindow();

                        stage.setScene(newScene);
                        stage.show();
                        System.out.println(us.getText());
                    } catch (IOException ex) {
                        throw new RuntimeException(ex);
                    }
                });
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public static boolean checkMyRequests() {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            // Установление соединения с базой данных
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            // SQL-запрос SELECT
            String sql = "select friend1_id,friend2_id,friendship_status from friendship where friend2_id='" + Logged.getLoggedInUser() + "' and friendship_status='request'";
            preparedStatement = connection.prepareStatement(sql);
            resultSet = preparedStatement.executeQuery();  // Вызов executeQuery() перед использованием resultSet
            while (resultSet.next()) {
                String user1 = resultSet.getString("friend1_id");
                String user2 = resultSet.getString("friend2_id");
                String status = resultSet.getString("friendship_status");
                return true;
            }

            return false;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public static void loadMessages(VBox listvbox, List<VBox> messages) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            // Установление соединения с базой данных
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            // SQL-запрос SELECT
            String sql = "SELECT id, fromuser, touser, message FROM  (SELECT id, fromuser, touser, message, ROW_NUMBER() OVER (PARTITION BY CASE WHEN fromuser = '" + Logged.getLoggedInUser() + "' THEN touser ELSE fromuser END ORDER BY id DESC) as row_num FROM messages WHERE '" + Logged.getLoggedInUser() + "' IN (fromuser, touser)) WHERE row_num = 1 order by id desc;";
            preparedStatement = connection.prepareStatement(sql);

            resultSet = preparedStatement.executeQuery();  // Вызов executeQuerfry() перед использованием resultSet

            while (resultSet.next()) {
                String fromuser = resultSet.getString("fromuser");
                String touser = resultSet.getString("touser");
                String messageFrom = resultSet.getString("message");
                System.out.println(fromuser + " " + touser);
                Label us = new Label();
                us.setStyle("-fx-font-size: 19; -fx-font-weight: bold;");

                Label msg = new Label();
                msg.setStyle("-fx-font-size: 15;");

                VBox v = new VBox();
                v.setStyle("-fx-background-color: #e9d787; -fx-background-radius: 30; -fx-padding: 0 15 0 15;");
                v.setMinSize(715, 53);
                v.setMaxSize(715, 53);
                if (!Logged.getLoggedInUser().equals(fromuser)) {
                    us.setText(fromuser);
                    msg.setText(fromuser + ": " + messageFrom);
                }
                if (!Logged.getLoggedInUser().equals(touser)) {

                    us.setText(touser);
                    msg.setText("Me" + ": " + messageFrom);
                }

                v.getChildren().addAll(us, msg);
                listvbox.getChildren().add(v);
                messages.add(v);
                v.setOnMouseClicked(event ->
                {
                    try {
                        ClickedUser.setClicked(us.getText());
                        Parent root = FXMLLoader.load(DB.class.getResource("messageswithuser.fxml"));
                        Scene newScene = new Scene(root);

                        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

                        stage.setScene(newScene);
                        stage.show();
                    } catch (IOException e) {
                        e.printStackTrace();  // Log the exception for debugging
                    }
                });
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (resultSet != null) resultSet.close();
                if (preparedStatement != null) preparedStatement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    public static void insertMessageIntoDatabase(String message, String fromUser, String toUser) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            // Establish a connection to the database
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            // SQL query with parameters
            String sql = "INSERT INTO messages (message,fromuser, touser) VALUES (?,?,?)";

            // Create a PreparedStatement
            preparedStatement = connection.prepareStatement(sql);

            // Set parameter values
            preparedStatement.setString(1, message);
            preparedStatement.setString(2, fromUser);
            preparedStatement.setString(3, toUser);

            // Execute the INSERT query
            int rowsAffected = preparedStatement.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Insert successful!");
            } else {
                System.out.println("Insert failed.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // Close the PreparedStatement and the connection in the finally block
            try {
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public static void loadMessagesWithUser(String noMyUs,VBox message) throws SQLException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            // Установление соединения с базой данных
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            // SQL-запрос SELECT
            String sql = "select id, fromuser, touser, message from messages where fromuser='" + Logged.getLoggedInUser() + "' and touser='" + noMyUs + "' or fromuser='" + noMyUs + "' and touser='" + Logged.getLoggedInUser() + "'";
            preparedStatement = connection.prepareStatement(sql);

            resultSet = preparedStatement.executeQuery();  // Вызов executeQuery() перед использованием resultSet


            while (resultSet.next()) {
                String fromuser = resultSet.getString("fromuser");
                String touser = resultSet.getString("touser");
                String messageFrom = resultSet.getString("message");
                VBox a = new VBox();
                if (fromuser.equals(Logged.getLoggedInUser())) {
                    HBox hBox = new HBox();
                    hBox.setAlignment(Pos.CENTER_RIGHT);
                    hBox.setPadding(new Insets(5, 10, 5, 5));
                    Text textuser = new Text(messageFrom);
                    TextFlow textFlow = new TextFlow(textuser);
                    textFlow.setStyle("-fx-background-color: rgb(77,155,243); -fx-background-radius: 20px;");
                    textFlow.setPadding(new Insets(5, 10, 5, 10));
                    hBox.getChildren().add(textFlow);
                    message.getChildren().add(hBox);
                } else if (fromuser.equals(noMyUs)) {
                    HBox hBox = new HBox();
                    hBox.setAlignment(Pos.CENTER_LEFT);
                    hBox.setPadding(new Insets(5, 5, 5, 10));
                    Text textuser = new Text(messageFrom);
                    TextFlow textFlow = new TextFlow(textuser);
                    textFlow.setStyle("-fx-background-color: rgb(233,233,235); -fx-background-radius: 20px;");
                    textFlow.setPadding(new Insets(5, 10, 5, 10));
                    hBox.getChildren().add(textFlow);
                    message.getChildren().add(hBox);
                }

            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    public static void loadMyRequests(VBox vBox){
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            // Установление соединения с базой данных
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            // SQL-запрос SELECT
            String sql = "select friend1_id,friend2_id,friendship_status from friendship where friend2_id='" + Logged.getLoggedInUser() + "' and friendship_status='request'";
            preparedStatement = connection.prepareStatement(sql);
            resultSet = preparedStatement.executeQuery();  // Вызов executeQuery() перед использованием resultSet
            while (resultSet.next()) {
                String user1 = resultSet.getString("friend1_id");
                String user2 = resultSet.getString("friend2_id");
                String status = resultSet.getString("friendship_status");
                ImageView check = new ImageView(new Image("C:\\Users\\dzang\\IdeaProjects\\FinalProjectSoftware\\src\\main\\resources\\com\\example\\finalprojectsoftware\\check.png"));
                ImageView cross = new ImageView(new Image("C:\\Users\\dzang\\IdeaProjects\\FinalProjectSoftware\\src\\main\\resources\\com\\example\\finalprojectsoftware\\cross.png"));
                check.setFitHeight(44);
                check.setFitWidth(40);
                cross.setFitHeight(37);
                cross.setFitWidth(32);

                VBox v = new VBox();
                v.setStyle("-fx-background-color: #e9d787; -fx-background-radius: 30; -fx-padding: 0 15 0 15;");
                Label us = new Label();
                us.setStyle("-fx-font-size: 19; -fx-font-weight: bold;");
                us.setText(user1);
                HBox h = new HBox();
                h.setSpacing(5);
                v.getChildren().add(us);
                v.setMinSize(635, 53);
                v.setMaxSize(635, 53);
                v.setAlignment(Pos.CENTER_LEFT);
                h.getChildren().addAll(v,check,cross);
                h.setAlignment(Pos.CENTER);
                vBox.getChildren().add(h);
                v.setOnMouseClicked(event -> {
                    // Ваш код для обработки события при нажатии на VBox
                    System.out.println(((Label) v.getChildren().get(0)).getText());
                    ClickedUser.setClicked(us.getText());
                    Parent root = null;
                    try {
                        root = FXMLLoader.load(DB.class.getResource("Profile.fxml"));
                        Scene newScene = new Scene(root);

                        Stage stage = (Stage) ((Node)event.getSource()).getScene().getWindow();

                        stage.setScene(newScene);

                        stage.show();
                    } catch (IOException e) {
                        throw new RuntimeException(e);
                    }
                    // Добавьте сюда код, который вы хотите выполнить при нажатии на VBox
                });
                check.setPickOnBounds(true);
                cross.setPickOnBounds(true);
                check.setOnMouseClicked(event->{
                    System.out.println(((Label) v.getChildren().get(0)).getText()+"?");
                    acceptRequest(us.getText());
                    vBox.getChildren().remove(h);
                });
                cross.setOnMouseClicked(event -> {
                    System.out.println(((Label) v.getChildren().get(0)).getText()+"?");
                    cancelRequest(us.getText());
                    vBox.getChildren().remove(h);
                });
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    public static void commentLogicAndDesign(int wallid,VBox commentListVBOX) {
        commentListVBOX.getChildren().clear();
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            // Установление соединения с базой данных
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            // SQL-запрос SELECT
            String sql = "select commentwallid,wallid,username,text from commentwall where wallid="+wallid;
            preparedStatement = connection.prepareStatement(sql);
            resultSet = preparedStatement.executeQuery();  // Вызов executeQuery() перед использованием resultSet
            while (resultSet.next()) {
                String user = resultSet.getString("username");
                String text = resultSet.getString("text");
                VBox v = new VBox();
                AnchorPane anchorPane = new AnchorPane();
                anchorPane.setMinSize(360, 1);
                anchorPane.setMaxSize(360, 1);
                anchorPane.setPadding(new Insets(0,0,0,10));
                anchorPane.setStyle("-fx-background-color: black;");
                v.getChildren().add(anchorPane);
                Text username = new Text(user);

                TextFlow users = new TextFlow(username);
                users.setStyle("-fx-font-size: 25; -fx-font-weight: bold;");
                users.setPadding(new Insets(0, 0, 0, 5));
                v.getChildren().add(users);
                Text texts = new Text(text);

                TextFlow txt = new TextFlow(texts);
                txt.setStyle("-fx-font-size: 15;");
                txt.setPadding(new Insets(0, 0, 0, 5));
                v.getChildren().add(txt);

                AnchorPane anchorPane1 = new AnchorPane();
                anchorPane1.setMinSize(360, 1);
                anchorPane1.setMaxSize(360, 1);
                anchorPane1.setStyle("-fx-background-color: black;");
                v.getChildren().add(anchorPane1);
                commentListVBOX.getChildren().add(v);
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    public static void insertIntoComment(TextField textField) throws SQLException {
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement statement = connection.prepareStatement("INSERT INTO commentwall (wallid,username,text) VALUES (?, ?,?)")) {
            statement.setInt(1, getWall());
            statement.setString(2, Logged.getLoggedInUser());
            statement.setString(3, textField.getText());
            statement.executeUpdate();
        }
    }
    static int w;
    static void setWall(int w){
        DB.w=w;
    }
    static int getWall(){
        return w;
    }
    public static void loadWalls(VBox vbox, AnchorPane commentPane, VBox commentListVBOX, String us, ScrollPane scrollPaneComment){
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            // Установление соединения с базой данных
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            // SQL-запрос SELECT
            String sql = "select wallid,username,text,wheree from walls where wheree='"+us+"' order by wallid desc;";
            preparedStatement = connection.prepareStatement(sql);
            resultSet = preparedStatement.executeQuery();  // Вызов executeQuery() перед использованием resultSet
            while (resultSet.next()) {
                String user = resultSet.getString("username");
                String text = resultSet.getString("text");
                int wallid = resultSet.getInt("wallid");
                String wheree = resultSet.getString("wheree");
                VBox v = new VBox();
                AnchorPane anchorPane=new AnchorPane();
                anchorPane.setMinSize(700,1);
                anchorPane.setMaxSize(700,1);
                anchorPane.setStyle("-fx-background-color: black;");
                v.getChildren().add(anchorPane);
                Text username = new Text(user);
//                username.setStyle("-fx-font-size: 25; -fx-font-weight: bold;");
//                VBox.setMargin(username,new Insets(0,0,0,5));
                TextFlow users = new TextFlow(username);
                users.setStyle("-fx-font-size: 25; -fx-font-weight: bold;");
                users.setPadding(new Insets(0,0,0,5));
                v.getChildren().add(users);
                Text texts =new Text(text);
//                texts.setStyle("-fx-font-size: 15;");
//                VBox.setMargin(texts,new Insets(0,0,0,10));
                TextFlow txt = new TextFlow(texts);
                txt.setStyle("-fx-font-size: 15;");
                txt.setPadding(new Insets(0,0,0,10));
                v.getChildren().add(txt);
                HBox hBox = new HBox();
                ImageView like = new ImageView(new Image("C:\\Users\\dzang\\IdeaProjects\\FinalProjectSoftware\\src\\main\\resources\\com\\example\\finalprojectsoftware\\love.png"));
                like.setFitWidth(31);
                like.setFitHeight(37);
                ImageView comment = new ImageView(new Image("C:\\Users\\dzang\\IdeaProjects\\FinalProjectSoftware\\src\\main\\resources\\com\\example\\finalprojectsoftware\\chat.png"));
                comment.setFitWidth(41);
                comment.setFitHeight(45);
                hBox.getChildren().addAll(like,comment);
                hBox.setAlignment(Pos.CENTER_LEFT);
                v.getChildren().add(hBox);
                AnchorPane anchorPane1=new AnchorPane();
                anchorPane1.setMinSize(700,1);
                anchorPane1.setMaxSize(700,1);
                anchorPane1.setStyle("-fx-background-color: black;");
                v.getChildren().add(anchorPane1);
                vbox.getChildren().add(v);
                like.setPickOnBounds(true);
                comment.setPickOnBounds(true);
                AtomicBoolean checkLike= new AtomicBoolean(checkLike(wallid));
                if(checkLike.get()){
                    like.setImage(new Image("C:\\Users\\dzang\\IdeaProjects\\FinalProjectSoftware\\src\\main\\resources\\com\\example\\finalprojectsoftware\\heart (1).png"));
                }
                else {
                    like.setImage(new Image("C:\\Users\\dzang\\IdeaProjects\\FinalProjectSoftware\\src\\main\\resources\\com\\example\\finalprojectsoftware\\love.png"));
                }
                texts.setOnMouseClicked(event ->{
                    System.out.println("clicked");
                });
                like.setOnMouseClicked(e->{
                    System.out.println("like");
                    if(!checkLike.get()){
                        like.setImage(new Image("C:\\Users\\dzang\\IdeaProjects\\FinalProjectSoftware\\src\\main\\resources\\com\\example\\finalprojectsoftware\\heart (1).png"));
                        checkLike.set(true);
                        try {
                            insertIntoLike(wallid);
                        } catch (SQLException ex) {
                            throw new RuntimeException(ex);
                        }
                    }
                    else {
                        like.setImage(new Image("C:\\Users\\dzang\\IdeaProjects\\FinalProjectSoftware\\src\\main\\resources\\com\\example\\finalprojectsoftware\\love.png"));
                        checkLike.set(false);
                        deleteFromLike(wallid);
                    }
                });
                comment.setOnMouseClicked(e->{
                    System.out.println("comment");
                    commentPane.setVisible(true);
                    commentLogicAndDesign(wallid,commentListVBOX);
                    whenInsertWallid=wallid;
                    setWall(whenInsertWallid);
                    scrollPaneComment.setVvalue(1.0);
                    Platform.runLater(() -> {
                        // Allow JavaFX to perform layout and rendering
                        PauseTransition pause = new PauseTransition(Duration.millis(50));
                        pause.setOnFinished(ee -> {
                            // Scroll to the bottom of the VBox
                            commentListVBOX.layout();
                            scrollPaneComment.setVvalue(1.0);
                        });
                        pause.play();
                    });
                });
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    static int wid;
    public static void loadNews(VBox vbox,AnchorPane commentPane, VBox commentListVBOX,ScrollPane scrollPaneComment){
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            // Установление соединения с базой данных
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            // SQL-запрос SELECT
            String sql = "SELECT wallid, username, text, wheree, friend1_id, friend2_id FROM walls w " + "JOIN friendship f ON w.username = f.friend1_id OR w.username = f.friend2_id " + "WHERE " +
                    "friendship_status = 'accept' " + "AND (friend1_id = '"+Logged.getLoggedInUser()+"' OR friend2_id = '"+Logged.getLoggedInUser()+"') " + "AND username <> '"+Logged.getLoggedInUser()+"' " +
                    "ORDER BY wallid DESC;";
            preparedStatement = connection.prepareStatement(sql);
            resultSet = preparedStatement.executeQuery();  // Вызов executeQuery() перед использованием resultSet
            while (resultSet.next()) {

                String user1 = resultSet.getString("friend1_id");
                String user2 = resultSet.getString("friend2_id");
                String whoWritten = resultSet.getString("username");
                String text = resultSet.getString("text");
                String whereWritten = resultSet.getString("wheree");
                int wallid = resultSet.getInt("wallid");
                VBox v = new VBox();
                AnchorPane anchorPane=new AnchorPane();
                anchorPane.setMinSize(700,1);
                anchorPane.setMaxSize(700,1);
                anchorPane.setStyle("-fx-background-color: black;");
                v.getChildren().add(anchorPane);

                Text username = new Text();

                username.setText(whoWritten);
                TextFlow users = new TextFlow(username);
                users.setStyle("-fx-font-size: 25; -fx-font-weight: bold;");
                users.setPadding(new Insets(0,0,0,5));
                v.getChildren().add(users);
                Text texts =new Text(text);
                TextFlow txt = new TextFlow(texts);
                txt.setStyle("-fx-font-size: 15;");
                txt.setPadding(new Insets(0,0,0,10));
                v.getChildren().add(txt);
                HBox hBox = new HBox();
                ImageView like = new ImageView(new Image("C:\\Users\\dzang\\IdeaProjects\\FinalProjectSoftware\\src\\main\\resources\\com\\example\\finalprojectsoftware\\love.png"));
                like.setFitWidth(31);
                like.setFitHeight(37);
                ImageView comment = new ImageView(new Image("C:\\Users\\dzang\\IdeaProjects\\FinalProjectSoftware\\src\\main\\resources\\com\\example\\finalprojectsoftware\\chat.png"));
                comment.setFitWidth(41);
                comment.setFitHeight(45);
                hBox.getChildren().addAll(like,comment);
                hBox.setAlignment(Pos.CENTER_LEFT);
                v.getChildren().add(hBox);
                AnchorPane anchorPane1=new AnchorPane();
                anchorPane1.setMinSize(700,1);
                anchorPane1.setMaxSize(700,1);
                anchorPane1.setStyle("-fx-background-color: black;");
                v.getChildren().add(anchorPane1);
                vbox.getChildren().add(v);
                like.setPickOnBounds(true);
                comment.setPickOnBounds(true);
                AtomicBoolean checkLike= new AtomicBoolean(checkLike(wallid));
                if(checkLike.get()){
                    like.setImage(new Image("C:\\Users\\dzang\\IdeaProjects\\FinalProjectSoftware\\src\\main\\resources\\com\\example\\finalprojectsoftware\\heart (1).png"));
                }
                else {
                    like.setImage(new Image("C:\\Users\\dzang\\IdeaProjects\\FinalProjectSoftware\\src\\main\\resources\\com\\example\\finalprojectsoftware\\love.png"));
                }
                texts.setOnMouseClicked(event ->{
                    System.out.println("clicked");
                });
                like.setOnMouseClicked(e->{
                    System.out.println("like");
                    if(!checkLike.get()){
                        like.setImage(new Image("C:\\Users\\dzang\\IdeaProjects\\FinalProjectSoftware\\src\\main\\resources\\com\\example\\finalprojectsoftware\\heart (1).png"));
                        checkLike.set(true);
                        try {
                            insertIntoLike(wallid);
                        } catch (SQLException ex) {
                            throw new RuntimeException(ex);
                        }
                    }
                    else {
                        like.setImage(new Image("C:\\Users\\dzang\\IdeaProjects\\FinalProjectSoftware\\src\\main\\resources\\com\\example\\finalprojectsoftware\\love.png"));
                        checkLike.set(false);
                        deleteFromLike(wallid);
                    }
                });
                comment.setOnMouseClicked(e->{
                    setWall(wallid);
                    commentListVBOX.getChildren().clear();
                    System.out.println("comment");
                    commentPane.setVisible(true);
                    commentLogicAndDesign(wallid,commentListVBOX);
                    scrollPaneComment.setVvalue(1.0);
                    Platform.runLater(() -> {
                        // Allow JavaFX to perform layout and rendering
                        PauseTransition pause = new PauseTransition(Duration.millis(50));
                        pause.setOnFinished(ee -> {
                            // Scroll to the bottom of the VBox
                            commentListVBOX.layout();
                            scrollPaneComment.setVvalue(1.0);
                        });
                        pause.play();
                    });
                });
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    public static void insertIntoLike(int wallid) throws SQLException {
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement statement = connection.prepareStatement("INSERT INTO likewall (wallid, username) VALUES (?, ?)")) {
            statement.setInt(1, wallid);
            statement.setString(2, Logged.getLoggedInUser());
            statement.executeUpdate();
        }
    }
    public static void insertIntoWall(TextField textfield,VBox vbox,AnchorPane commentPane) throws SQLException {
        VBox v = new VBox();
        AnchorPane anchorPane=new AnchorPane();
        anchorPane.setMinSize(700,1);
        anchorPane.setMaxSize(700,1);
        anchorPane.setStyle("-fx-background-color: black;");
        v.getChildren().add(anchorPane);
        Text username = new Text(Logged.getLoggedInUser());
        TextFlow users = new TextFlow(username);
        users.setStyle("-fx-font-size: 25; -fx-font-weight: bold;");
        users.setPadding(new Insets(0,0,0,5));
        v.getChildren().add(users);
        Text texts =new Text(textfield.getText());
        TextFlow txt = new TextFlow(texts);
        txt.setStyle("-fx-font-size: 15;");
        txt.setPadding(new Insets(0,0,0,10));
        v.getChildren().add(txt);
        HBox hBox = new HBox();
        ImageView like = new ImageView(new Image("C:\\Users\\dzang\\IdeaProjects\\FinalProjectSoftware\\src\\main\\resources\\com\\example\\finalprojectsoftware\\love.png"));
        like.setFitWidth(31);
        like.setFitHeight(37);
        ImageView comment = new ImageView(new Image("C:\\Users\\dzang\\IdeaProjects\\FinalProjectSoftware\\src\\main\\resources\\com\\example\\finalprojectsoftware\\chat.png"));
        comment.setFitWidth(41);
        comment.setFitHeight(45);
        hBox.getChildren().addAll(like,comment);
        hBox.setAlignment(Pos.CENTER_LEFT);
        v.getChildren().add(hBox);
        AnchorPane anchorPane1=new AnchorPane();
        anchorPane1.setMinSize(700,1);
        anchorPane1.setMaxSize(700,1);
        anchorPane1.setStyle("-fx-background-color: black;");
        v.getChildren().add(anchorPane1);
        vbox.getChildren().add(0,v);
        like.setPickOnBounds(true);
        comment.setPickOnBounds(true);
        insertIntoWalls(textfield.getText(),Logged.getLoggedInUser());
        textfield.setText("");
        AtomicBoolean checkLike= new AtomicBoolean(false);
        if(checkLike.get()){
            like.setImage(new Image("C:\\Users\\dzang\\IdeaProjects\\FinalProjectSoftware\\src\\main\\resources\\com\\example\\finalprojectsoftware\\heart (1).png"));
        }
        else {
            like.setImage(new Image("C:\\Users\\dzang\\IdeaProjects\\FinalProjectSoftware\\src\\main\\resources\\com\\example\\finalprojectsoftware\\love.png"));
        }
        texts.setOnMouseClicked(eevent ->{
            System.out.println("clicked");
        });
        like.setOnMouseClicked(e->{
            System.out.println("like");
            if(!checkLike.get()){
                like.setImage(new Image("C:\\Users\\dzang\\IdeaProjects\\FinalProjectSoftware\\src\\main\\resources\\com\\example\\finalprojectsoftware\\heart (1).png"));
                checkLike.set(true);
                try {
                    insertIntoLike(wallingid);
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
            }
            else {
                like.setImage(new Image("C:\\Users\\dzang\\IdeaProjects\\FinalProjectSoftware\\src\\main\\resources\\com\\example\\finalprojectsoftware\\love.png"));
                checkLike.set(false);
                deleteFromLike(wallingid);
            }
        });
        comment.setOnMouseClicked(e->{
            System.out.println("comment");
            commentPane.setVisible(true);
        });
    }
    public static void deleteFromLike(int wallid) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            // Установление соединения с базой данных
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            String sql = "delete from likewall where wallid="+wallid+" and username='"+Logged.getLoggedInUser()+"'";
            preparedStatement = connection.prepareStatement(sql);

            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    static boolean checkLike(int wallid) throws SQLException {
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement statement = connection.prepareStatement("SELECT wallid,username FROM likewall WHERE wallid = ? and username = ?")) {
            statement.setInt(1, wallid);
            statement.setString(2, Logged.getLoggedInUser());
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    System.out.println("exist");
                    return true;//exist
                } else {
                    return false;//not exist
                }
            }
        }
    }
    static int wallingid;
    static int whenInsertWallid;
    static int insertIntoWalls(String textfield, String user) throws SQLException {
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement statement = connection.prepareStatement("INSERT INTO walls (username,text,wheree) VALUES (?, ?,?)", Statement.RETURN_GENERATED_KEYS)) {
            statement.setString(1, Logged.getLoggedInUser());
            statement.setString(2, textfield);
            statement.setString(3,user);
            int affectedRows = statement.executeUpdate();
            if (affectedRows > 0) {
                // Получаем сгенерированные ключи
                try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        int wallId = generatedKeys.getInt(1);
                        whenInsertWallid=wallId;
                        System.out.println("Сгенерированный wallId: " + wallId);
                        return wallId;
                        // Теперь у вас есть значение wallId, которое вы можете использовать по своему усмотрению
                        // Например, вы можете его сохранить в переменной, передать в другой метод и т.д.
                    } else {
                        System.out.println("Не удалось получить сгенерированный wallId.");
                    }
                }
            } else {
                System.out.println("Операция вставки не выполнена, ни одна строка не была изменена.");
            }
        }
        catch (SQLException e) {
            e.printStackTrace(); // Выводим стек трейса ошибки
            System.out.println("SQL Exception: " + e.getMessage());
        }
        return 0;
    }
    static void cancelRequest(String usernameString) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            // Установление соединения с базой данных
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            String sql = "delete from friendship where friend1_id='"+usernameString+"' and friend2_id='"+Logged.getLoggedInUser()+"'";
            preparedStatement = connection.prepareStatement(sql);

            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
        static void acceptRequest(String usernameString){
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            // Установление соединения с базой данных
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            String sql = "UPDATE friendship " +
                    "SET friendship_status = 'accept' " +
                    "WHERE friend1_id='"+usernameString+"' and friend2_id='"+Logged.getLoggedInUser()+"'";
            preparedStatement = connection.prepareStatement(sql);

            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    static void removeRequest(String usernameString){
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            // Установление соединения с базой данных
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            String sql = "delete from friendship where friend1_id='"+Logged.getLoggedInUser()+"' and friend2_id='"+usernameString+"'";
            preparedStatement = connection.prepareStatement(sql);

            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    static String statusFromMe(String usernameString) throws SQLException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            // Установление соединения с базой данных
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            // SQL-запрос SELECT
            String sql = "select friendship_status from friendship where friend1_id='" + Logged.getLoggedInUser() + "' and friend2_id='" + usernameString + "'";
            preparedStatement = connection.prepareStatement(sql);

            resultSet = preparedStatement.executeQuery();  // Вызов executeQuery() перед использованием resultSet
            String messageFrom = "";
            while (resultSet.next()) {
                messageFrom = resultSet.getString("friendship_status");
            }
            return messageFrom;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    static String statusFromOther(String usernameString){
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            // Установление соединения с базой данных
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            // SQL-запрос SELECT
            String sql = "select friendship_status from friendship where friend1_id='" + usernameString + "' and friend2_id='" + Logged.getLoggedInUser() + "'";
            preparedStatement = connection.prepareStatement(sql);

            resultSet = preparedStatement.executeQuery();  // Вызов executeQuery() перед использованием resultSet
            String messageFrom = "";
            while (resultSet.next()) {
                messageFrom = resultSet.getString("friendship_status");
            }
            return messageFrom;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    static void addFriend(String usernameString){
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            // Establish a connection to the database
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            // SQL query with parameters
            String sql = "INSERT INTO friendship (friend1_id,friend2_id, friendship_status) VALUES (?,?,?)";

            // Create a PreparedStatement
            preparedStatement = connection.prepareStatement(sql);

            // Set parameter values
            preparedStatement.setString(1, Logged.getLoggedInUser());
            preparedStatement.setString(2, usernameString);
            preparedStatement.setString(3, "request");

            // Execute the INSERT query
            int rowsAffected = preparedStatement.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Insert successful!");
            } else {
                System.out.println("Insert failed.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // Close the PreparedStatement and the connection in the finally block
            try {
                if (preparedStatement != null) {
                    preparedStatement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public static void loadsFriends(String username, List<String> myFriendList) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            // Установление соединения с базой данных
            connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            // SQL-запрос SELECT
            String sql = "select friend1_id,friend2_id,friendship_status from friendship where friend1_id='" + username + "' and friendship_status='accept' or friend2_id='" + username + "' and friendship_status='accept'";
            preparedStatement = connection.prepareStatement(sql);
            resultSet = preparedStatement.executeQuery();  // Вызов executeQuery() перед использованием resultSet
            FriendGroup friendGroup = new FriendGroup("Friends");

            while (resultSet.next()) {
                String user1 = resultSet.getString("friend1_id");
                String user2 = resultSet.getString("friend2_id");
                String status = resultSet.getString("friendship_status");
                if (user1.equals(Logged.getLoggedInUser())) {
                    myFriendList.add(user2);

                } else if (user2.equals(Logged.getLoggedInUser())) {
                    myFriendList.add(user1);

                }
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    public static void search(TextField searchTextField, MouseEvent event){
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement statement = connection.prepareStatement("SELECT username FROM users WHERE username = ?")) {
            statement.setString(1, searchTextField.getText().trim());
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    System.out.println("User found");
                    if(!searchTextField.getText().trim().equals(Logged.getLoggedInUser())) {
                        ClickedUser.setClicked(searchTextField.getText().trim());
                        Parent root = FXMLLoader.load(DB.class.getResource("Profile.fxml"));

                        Scene newScene = new Scene(root);

                        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

                        stage.setScene(newScene);

                        stage.show();
                    }
                    else {
                        ClickedUser.setClicked(searchTextField.getText().trim());
                        Parent root = FXMLLoader.load(DB.class.getResource("myProfile.fxml"));

                        Scene newScene = new Scene(root);

                        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

                        stage.setScene(newScene);

                        stage.show();
                    }
                } else {
                    System.out.println("User did not find");
                }
            }
        } catch (SQLException | IOException e) {
            e.printStackTrace();
        }
    }
}
