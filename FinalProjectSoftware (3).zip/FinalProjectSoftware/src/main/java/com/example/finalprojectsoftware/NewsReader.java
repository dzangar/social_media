package com.example.finalprojectsoftware;

import javafx.application.Platform;

public class NewsReader implements NewsObserver {
    private String name;

    public NewsReader(String name) {
        this.name = name;
    }

    @Override
    public void update(String news) {
        Platform.runLater(() -> {
            // News reader receives and displays news
            System.out.println(name + " received news: " + news);
        });
    }

    // Add a method to start the NewsReader asynchronously
    public void start() {
        Thread thread = new Thread(this::run);
        thread.start();
    }

    // Add a method to simulate continuous updates (for demonstration purposes)
    public void run() {
        // Simulate getting news from a source (replace with actual logic)
        String realNews = getNewsFromSource();
        update(realNews);
    }

    // Simulate getting news from a source (replace this with your actual logic)
    private String getNewsFromSource() {
        // Replace this with logic to get news from your actual source
        // For example, you might use an API call to a news service
        return "Actual news update!";
    }
}
