package com.example.finalprojectsoftware;

import javafx.scene.control.Label;
import javafx.scene.layout.VBox;

import java.util.ArrayList;
import java.util.List;

// Группа друзей (композит)
public class FriendGroup implements FriendComponent {
    private String groupName;
    private List<FriendComponent> friends = new ArrayList<>();

    public FriendGroup(String groupName) {
        this.groupName = groupName;
    }

    public void addFriend(FriendComponent friend) {
        friends.add(friend);
    }

    @Override
    public void display(VBox container) {
        // Display the group information (if needed)
        // ...

        // Display each friend in the group
        for (FriendComponent friend : friends) {
            friend.display(container);
        }
    }
}
