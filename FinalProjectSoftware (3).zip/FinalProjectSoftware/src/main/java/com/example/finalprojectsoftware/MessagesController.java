package com.example.finalprojectsoftware;

import javafx.event.ActionEvent;
import javafx.event.EventType;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MessagesController {
    private static final String DB_URL = "jdbc:postgresql://localhost:5432/a";
    private static final String DB_USER = "postgres";
    private static final String DB_PASSWORD = "root";
    @FXML
    private Label message;

    @FXML
    private VBox messagedesign;

    @FXML
    private Label username;

    List<VBox> messages = new ArrayList<>();
    String myusername=Logged.getLoggedInUser();
    private DatagramSocket socket;

    private InetAddress address;

    @FXML
    private VBox listvbox;

    private static final int SERVER_PORT = 8000;

    public MessagesController() throws UnknownHostException, SocketException {
        socket = new DatagramSocket();
        address = InetAddress.getByName("localhost");
    }

    @FXML
    void initialize() throws IOException {
        ClientThreadForMessagePage clientThread = new ClientThreadForMessagePage(socket, listvbox,messages);
        ChatControllerForPage chatController = new ChatControllerForPage();
        clientThread.addObserver(chatController);
        clientThread.start();
        byte[] uuid = ("init;" + Logged.getLoggedInUser()).getBytes();
        DatagramPacket initialize = new DatagramPacket(uuid, uuid.length, address, Server.PORT);
        socket.send(initialize);
        DB.loadMessages(listvbox,messages);
    }
    @FXML
    void friends(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("friends.fxml"));

        Scene newScene = new Scene(root);

        Stage stage = (Stage) ((Node)event.getSource()).getScene().getWindow();

        stage.setScene(newScene);

        stage.show();
    }

    @FXML
    void messages(ActionEvent event) throws IOException {

        Parent root = FXMLLoader.load(getClass().getResource("messages.fxml"));

        Scene newScene = new Scene(root);

        Stage stage = (Stage) ((Node)event.getSource()).getScene().getWindow();

        stage.setScene(newScene);

        stage.show();
    }

    @FXML
    void myprofile(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("myProfile.fxml"));

        Scene newScene = new Scene(root);

        Stage stage = (Stage) ((Node)event.getSource()).getScene().getWindow();

        stage.setScene(newScene);

        stage.show();
    }


    @FXML
    void news(ActionEvent event) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("news.fxml"));

        Scene newScene = new Scene(root);

        Stage stage = (Stage) ((Node)event.getSource()).getScene().getWindow();

        stage.setScene(newScene);

        stage.show();
    }

    @FXML
    void search(ActionEvent event) {

    }
    private static String loggedInUser;
    public static void setLoggedInUser(String user) {
        loggedInUser = user;
    }
    public static String getLoggedInUser() {
        return loggedInUser;
    }

    @FXML
    private TextField searchTextField;
    @FXML
    void searchButton(MouseEvent event) throws IOException {
        DB.search(searchTextField,event);
    }

}
