package com.example.finalprojectsoftware;

//Abstract factory
public abstract class FriendFactory {
    public abstract FriendComponent createFriend(String friendName);
}

//Below concrete factories
 class FriendLeafFactory extends FriendFactory {
    @Override
    public FriendComponent createFriend(String friendName) {
        return new FriendLeaf(friendName);
    }
}
 class FriendGroupFactory extends FriendFactory {
    @Override
    public FriendComponent createFriend(String groupName) {
        return new FriendGroup(groupName);
    }
}
