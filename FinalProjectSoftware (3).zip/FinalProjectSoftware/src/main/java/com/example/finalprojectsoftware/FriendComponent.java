package com.example.finalprojectsoftware;

import javafx.scene.layout.VBox;

public interface FriendComponent {

    void display(VBox container);
}
