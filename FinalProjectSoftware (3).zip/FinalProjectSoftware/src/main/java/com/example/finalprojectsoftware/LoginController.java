package com.example.finalprojectsoftware;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.sql.*;

public class LoginController {
    private static final String DB_URL = "jdbc:postgresql://localhost:5432/a";
    private static final String DB_USER = "postgres";
    private static final String DB_PASSWORD = "root";
    @FXML
    private PasswordField password;

    @FXML
    private TextField username;
    @FXML
    private Text loginfailed;
    @FXML
    void registerButton(ActionEvent event) throws Exception{
        Parent root = FXMLLoader.load(getClass().getResource("Register.fxml"));

        Scene newScene = new Scene(root);

        Stage stage = (Stage) ((Node)event.getSource()).getScene().getWindow();

        stage.setScene(newScene);

        stage.show();
    }
    @FXML
    void loginButton(ActionEvent event) throws Exception {
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement statement = connection.prepareStatement("SELECT * FROM users WHERE username = ? AND password = ?")) {
            statement.setString(1, username.getText());
            statement.setString(2, password.getText());
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    Logged.setLoggedInUser(username.getText());
                    Logged.setPassInUser(password.getText());
                    Parent root = FXMLLoader.load(getClass().getResource("news.fxml"));

                    Scene newScene = new Scene(root);

                    Stage stage = (Stage) ((Node)event.getSource()).getScene().getWindow();

                    stage.setScene(newScene);

                    stage.show();
                } else {
                    loginfailed.setVisible(true);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
