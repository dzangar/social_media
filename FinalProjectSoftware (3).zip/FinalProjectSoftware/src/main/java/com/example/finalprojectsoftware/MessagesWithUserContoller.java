package com.example.finalprojectsoftware;

import javafx.animation.PauseTransition;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.IOException;
import java.net.*;
import java.sql.*;
import java.util.*;

public class MessagesWithUserContoller {
    private static final String DB_URL = "jdbc:postgresql://localhost:5432/a";
    private static final String DB_USER = "postgres";
    private static final String DB_PASSWORD = "root";
    String userUsernames=ClickedUser.getClicked();
    String myUsernames=Logged.getLoggedInUser();

    @FXML
    private AnchorPane colorMy;

    @FXML
    private AnchorPane colorUser;
    @FXML
    public VBox message=new VBox();

    @FXML
    private Label myMessage;

    @FXML
    private VBox myMessageUI;

    @FXML
    private Label myUsername;

    @FXML
    private TextField textfield;

    @FXML
    private Label userMessage;

    @FXML
    private VBox userMessageUI;

    @FXML
    private Label userUsername;

    @FXML
    private Label usernameInTop;

    @FXML
    private VBox vBoxMy;

    @FXML
    private VBox vboxOther;

    @FXML
    private ScrollPane scrollpane;

    List<VBox> messagetwo=new ArrayList<>();

    private DatagramSocket socket;

    private InetAddress address;

    public final String identifier = myUsernames +" " +userUsernames;
    private static final int SERVER_PORT = 8000;
//    public final ObservableList<Message> messagesList = FXCollections.observableArrayList();
    private List<Observer> observers = new ArrayList<>();


    public MessagesWithUserContoller() throws IOException {
        try {
            socket = new DatagramSocket();
            address = InetAddress.getByName("localhost");
        } catch (SocketException | UnknownHostException e) {
            throw new RuntimeException(e);
        }
    }

    @FXML
    void initialize() throws Exception {
        usernameInTop.setText(userUsernames);
        ClientThread clientThread = new ClientThread(socket,message,scrollpane);

        ChatController chatController = new ChatController();
        clientThread.addObserver(chatController);

        clientThread.start();
        System.out.println("work");
        // send initialization message to the server
        byte[] uuid = ("init;" + identifier).getBytes();
        DatagramPacket initialize = new DatagramPacket(uuid, uuid.length, address, Server.PORT);
        socket.send(initialize);
        DB.loadMessagesWithUser(userUsernames,message);


            textfield.setOnKeyPressed(event -> {
                if(!textfield.getText().trim().isEmpty()) {
                    if (event.getCode() == KeyCode.ENTER) {
                        String temp = identifier + ": " + textfield.getText().trim(); // message to send
//                        messagesList.add(new Message(temp, true)); // add message to ListView
                        byte[] msg = temp.getBytes(); // convert to bytes
                        HBox hBox = new HBox();
                        hBox.setAlignment(Pos.CENTER_RIGHT);
                        hBox.setPadding(new Insets(5, 10, 5, 5));
                        Text textuser = new Text(textfield.getText().trim());
                        TextFlow textFlow = new TextFlow(textuser);
                        textFlow.setStyle("-fx-background-color: rgb(77,155,243); -fx-background-radius: 20px;");
                        textFlow.setPadding(new Insets(5, 10, 5, 10));
                        hBox.getChildren().add(textFlow);
                        message.getChildren().add(hBox);
                        scrollpane.setVvalue(1.0);
                        // Scroll to the bottom of the VBox
                        Platform.runLater(() -> {
                            // Allow JavaFX to perform layout and rendering
                            PauseTransition pause = new PauseTransition(Duration.millis(50));
                            pause.setOnFinished(e -> {
                                // Scroll to the bottom of the VBox
                                message.layout();
                                scrollpane.setVvalue(1.0);
                            });
                            pause.play();
                        });
                        DB.insertMessageIntoDatabase(textuser.getText(), myUsernames, userUsernames);
                        textfield.setText(""); // remove text from input box

                        // create a packet & send
                        DatagramPacket send = new DatagramPacket(msg, msg.length, address, SERVER_PORT);
                        try {
                            socket.send(send);
                        } catch (IOException e) {
                            throw new RuntimeException(e);
                        }
                    }
                }
            });
        scrollpane.setVvalue(1.0);
            // Scroll to the bottom of the VBox
            Platform.runLater(() -> {
                // Allow JavaFX to perform layout and rendering
                PauseTransition pause = new PauseTransition(Duration.millis(50));
                pause.setOnFinished(e -> {
                    // Scroll to the bottom of the VBox
                    message.layout();
                    scrollpane.setVvalue(1.0);
                });
                pause.play();
            });
        }

    @FXML
    void friends(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("friends.fxml"));

        Scene newScene = new Scene(root);

        Stage stage = (Stage) ((Node)event.getSource()).getScene().getWindow();

        stage.setScene(newScene);

        stage.show();
    }

    @FXML
    void messages(ActionEvent event) throws IOException {

        Parent root = FXMLLoader.load(getClass().getResource("messages.fxml"));

        Scene newScene = new Scene(root);

        Stage stage = (Stage) ((Node)event.getSource()).getScene().getWindow();

        stage.setScene(newScene);

        stage.show();
    }

    @FXML
    void myprofile(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("myProfile.fxml"));

        Scene newScene = new Scene(root);

        Stage stage = (Stage) ((Node)event.getSource()).getScene().getWindow();

        stage.setScene(newScene);

        stage.show();
    }


    @FXML
    void news(ActionEvent event) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("news.fxml"));

        Scene newScene = new Scene(root);

        Stage stage = (Stage) ((Node)event.getSource()).getScene().getWindow();

        stage.setScene(newScene);

        stage.show();
    }

    @FXML
    void search(ActionEvent event) {

    }
    private static String loggedInUser;
    private static String userInUser;
    public static void setLoggedInUser(String user) {
        loggedInUser = user;
    }
    public static String getLoggedInUser() {
        return loggedInUser;
    }
    public static void setUserInUser(String user) {
        userInUser = user;
    }
    public static String getUserInUser() {
        return userInUser;
    }
    @FXML
    void send(MouseEvent event) {
        if(!textfield.getText().trim().isEmpty()) {
                String temp = identifier + ": " + textfield.getText().trim(); // message to send
                byte[] msg = temp.getBytes(); // convert to bytes

                HBox hBox = new HBox();
                hBox.setAlignment(Pos.CENTER_RIGHT);
                hBox.setPadding(new Insets(5, 10, 5, 5));
                Text textuser = new Text(textfield.getText().trim());
                TextFlow textFlow = new TextFlow(textuser);
                textFlow.setStyle("-fx-background-color: rgb(77,155,243); -fx-background-radius: 20px;");
                textFlow.setPadding(new Insets(5, 10, 5, 10));
                hBox.getChildren().add(textFlow);
                message.getChildren().add(hBox);
                scrollpane.setVvalue(1.0);
                // Scroll to the bottom of the VBox
                Platform.runLater(() -> {
                    // Allow JavaFX to perform layout and rendering
                    PauseTransition pause = new PauseTransition(Duration.millis(50));
                    pause.setOnFinished(e -> {
                        // Scroll to the bottom of the VBox
                        message.layout();
                        scrollpane.setVvalue(1.0);
                    });
                    pause.play();
                });
                DB.insertMessageIntoDatabase(textuser.getText(), myUsernames, userUsernames);
                textfield.setText(""); // remove text from input box

                // create a packet & send
                DatagramPacket send = new DatagramPacket(msg, msg.length, address, SERVER_PORT);
                try {
                    socket.send(send);
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
        }
    }
    @FXML
    private TextField searchTextField;
    @FXML
    void searchButton(MouseEvent event) throws IOException {
        DB.search(searchTextField,event);
    }
}

