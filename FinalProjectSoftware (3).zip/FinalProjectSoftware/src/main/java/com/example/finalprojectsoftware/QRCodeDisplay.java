package com.example.finalprojectsoftware;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.common.BitMatrix;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Color;

import java.util.HashMap;
import java.util.Map;

public class QRCodeDisplay implements MyProfileObserver {
    private String username;
    private ImageView qrCodeImageView;
    public QRCodeDisplay(ImageView qrCodeImageView, String username) {
        this.qrCodeImageView = qrCodeImageView;
        this.username=username;
    }

    @Override
    public void update() {
        System.out.println("QR Code Display is being updated.");

        // Generate QR code independently for testing
        String testData = "Login: "+username;
        if(username.equals(Logged.getLoggedInUser())){
            testData+="\nPassword: "+Logged.getPassInUser();
        }
        Image testQRCodeImage = generateQRCode(testData);

        if (testQRCodeImage != null) {
            qrCodeImageView.setImage(testQRCodeImage);
            System.out.println("QR Code generated successfully for testing.");
        } else {
            System.out.println("Failed to generate QR Code for testing.");
        }
    }
    private Image generateQRCode(String data) {
        int width = 200;
        int height = 200;

        Map<EncodeHintType, Object> hints = new HashMap<>();
        hints.put(EncodeHintType.CHARACTER_SET, "UTF-8");

        try {
            BitMatrix bitMatrix = new MultiFormatWriter().encode(data, BarcodeFormat.QR_CODE, width, height, hints);

            return matrixToImage(bitMatrix);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private Image matrixToImage(BitMatrix matrix) {
        int width = matrix.getWidth();
        int height = matrix.getHeight();

        javafx.scene.image.WritableImage image = new javafx.scene.image.WritableImage(width, height);

        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                image.getPixelWriter().setColor(x, y, matrix.get(x, y) ? javafx.scene.paint.Color.BLACK : Color.TRANSPARENT);
            }
        }

        return image;
    }
}