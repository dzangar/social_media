package com.example.finalprojectsoftware;

import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.util.*;

public class ClientThreadForMessagePage extends Thread implements Subject{
    private DatagramSocket socket;
    private List<MessageObserver> observers = new ArrayList<>();

    public ClientThreadForMessagePage(DatagramSocket socket, VBox listvbox, List<VBox> messages) {
        this.socket = socket;
        this.listvbox = listvbox;
        this.messages = messages;
    }


    @Override
    public void addObserver(MessageObserver observer) {
        observers.remove(observer);
        observers.add(observer);
    }

    @Override
    public void removeObserver(MessageObserver observer) {
        observers.remove(observer);
    }
    VBox listvbox;
    private List<VBox> messages;
    ScrollPane scrollpane;
    @Override
    public void notifyObservers(String message) {
        System.out.println("Notifying observers");
        for (MessageObserver observer : observers) {
            observer.setListMessages(messages);
            observer.setListVBox(listvbox);
            observer.update(message);
        }
        System.out.println("Finished notifying observers");
    }

    @Override
    public void run() {
        byte[] buffer = new byte[256];
        DatagramPacket packet = new DatagramPacket(buffer, buffer.length);

        try {
            while (true) {
                socket.receive(packet);
                String message = new String(packet.getData(), 0, packet.getLength());
                System.out.println("our " +message);
                notifyObservers(message);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
class ChatControllerForPage implements MessageObserver {
    private VBox listvbox;
    private ScrollPane scrollpane;
    private UpdateUICommandAdapterForPage updateUICommandAdapterForPage;
    private List<VBox> messages;
    private RawMessage rawMessage;

    @Override
    public void update(String message) {
        // Логика обновления интерфейса или другие операции при изменении состояния
        System.out.println("Received a new message: " + message);
        // Допустим, здесь происходит обновление чата с новым сообщением
        String fromUser = message.substring(0, message.indexOf(' '));
        String toUser = message.substring(message.indexOf(' ') + 1, message.indexOf(':'));
        message = message.substring(message.indexOf(':') + 2);
        rawMessage=new RawMessage(message,fromUser,toUser);
        if(toUser        //touser     admin users: hello
                .equals(Logged.getLoggedInUser())) {
            System.out.println("87");
            updateUICommandAdapterForPage = new UpdateUICommandAdapterForPage(rawMessage, listvbox, scrollpane,messages);
            updateUICommandAdapterForPage.execute();
        }
        System.out.println("update");
    }

    @Override
    public void setListVBox(VBox listvbox) {
        this.listvbox=listvbox;
    }

    @Override
    public void setScrollPane(ScrollPane scrollpane) {
        this.scrollpane=scrollpane;
    }

    @Override
    public void setListMessages(List<VBox> messages) {
        this.messages=messages;
    }
}
class UpdateUICommandForPage implements Command {
    private UIReceiverForPage receiver;
    private VBox listvbox;
    private String message;
    private VBox listvvbox;
    private ScrollPane scrollpane;
    private String fromUser;
    private String toUser;
    private List<VBox> messages;
    private Queue<String> messagesQueue = new LinkedList<>();


    public UpdateUICommandForPage(UIReceiverForPage uiReceiver, String adaptedMessage, String fromUser, String toUser) {
        this.receiver = uiReceiver;
        this.message = adaptedMessage;
        this.fromUser=fromUser;
        this.toUser=toUser;
    }
    @Override
    public void execute() {
        receiver.processMessage(message,fromUser,toUser);
    }
}

// Receiver
class UIReceiverForPage {
    private VBox listVBox;
    private ScrollPane scrollPane;
    private List<VBox> messages;

    public UIReceiverForPage(VBox listVBox, ScrollPane scrollPane, List<VBox> messages) {
        this.listVBox = listVBox;
        this.scrollPane = scrollPane;
        this.messages = messages;
    }

    void checkNameExist(String name) {
        Platform.runLater(() -> {
            Iterator<VBox> iterator = messages.iterator();
            while (iterator.hasNext()) {
                VBox message = iterator.next();
                javafx.scene.Node firstChild = message.getChildren().get(0);
                if (firstChild instanceof Label) {
                    Label label = (Label) firstChild;
                    if (label.getText().equals(name)) {
                        System.out.println("exist");
                        iterator.remove();
                        Platform.runLater(() -> listVBox.getChildren().remove(message));
                    }
                }
            }
        });

    }

    public void processMessage(String message, String fromUser, String toUser) {
            System.out.println("163");
            Label us = new Label();
            us.setStyle("-fx-font-size: 19; -fx-font-weight: bold;");

            Label msg = new Label();
            msg.setStyle("-fx-font-size: 15;");

            VBox v = new VBox();
            v.setStyle("-fx-background-color: #e9d787; -fx-background-radius: 30; -fx-padding: 0 15 0 15;");
            v.setMinSize(715, 53);
            v.setMaxSize(715, 53);
            System.out.println("executes " + fromUser + " " + toUser + ": " + message);
            if (!Logged.getLoggedInUser().equals(fromUser)) {
                us.setText(fromUser);
                msg.setText(fromUser + ": " + message);
            }
            if (Logged.getLoggedInUser().equals(fromUser)) {
                us.setText(toUser);
                msg.setText("Me" + ": " + message);
            }
            checkNameExist(us.getText());
            v.getChildren().addAll(us, msg);
            Platform.runLater(() -> {
                listVBox.getChildren().add(0, v);
                messages.add(0, v);
                for (VBox messaging : messages) {
                    messaging.setOnMouseClicked(event -> {
                        try {
                            ClickedUser.setClicked(us.getText());
                            Parent root = FXMLLoader.load(getClass().getResource("messageswithuser.fxml"));
                            Scene newScene = new Scene(root);

                            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();

                            stage.setScene(newScene);
                            stage.show();
                        } catch (IOException e) {
                            e.printStackTrace();  // Log the exception for debugging
                        }
                    });
                }
            });
    }
}
