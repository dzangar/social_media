package com.example.finalprojectsoftware;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MyFriendsRequestsController {

    @FXML
    private VBox vbox;
    @FXML
    void initialize() {
        DB.loadMyRequests(vbox);
    }

    @FXML
    void friends(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("friends.fxml"));

        Scene newScene = new Scene(root);

        Stage stage = (Stage) ((Node)event.getSource()).getScene().getWindow();

        stage.setScene(newScene);

        stage.show();
    }

    @FXML
    void messages(ActionEvent event) throws IOException {

        Parent root = FXMLLoader.load(getClass().getResource("messages.fxml"));

        Scene newScene = new Scene(root);

        Stage stage = (Stage) ((Node)event.getSource()).getScene().getWindow();

        stage.setScene(newScene);

        stage.show();
    }

    @FXML
    void myprofile(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("myProfile.fxml"));

        Scene newScene = new Scene(root);

        Stage stage = (Stage) ((Node)event.getSource()).getScene().getWindow();

        stage.setScene(newScene);

        stage.show();
    }


    @FXML
    void news(ActionEvent event) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("news.fxml"));

        Scene newScene = new Scene(root);

        Stage stage = (Stage) ((Node)event.getSource()).getScene().getWindow();

        stage.setScene(newScene);

        stage.show();
    }
    @FXML
    void search(ActionEvent event) {

    }
    @FXML
    private TextField searchTextField;
    @FXML
    void searchButton(MouseEvent event) throws IOException {
        DB.search(searchTextField,event);
    }
}
