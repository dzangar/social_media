package com.example.finalprojectsoftware;

interface NewsObserver {
    void run();

    void update(String news);
}