package com.example.finalprojectsoftware;

public class Logged {
    private static String loggedInUser;
    private static String passInUser;
    public static void setLoggedInUser(String user) {
        loggedInUser = user;
    }
    public static String getLoggedInUser() {
        return loggedInUser;
    }
    public static void setPassInUser(String password){
        passInUser=password;
    }
    public static String getPassInUser(){
        return passInUser;
    }
}
