package com.example.finalprojectsoftware;

interface NewsSubject {
    void addObserver(NewsObserver observer);
    void removeObserver(NewsObserver observer);
    void notifyObservers(String news);
}