package com.example.finalprojectsoftware;

import java.io.IOException;
import java.net.*;
import java.sql.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;

import javafx.animation.PauseTransition;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;
import javafx.stage.Stage;
import javafx.util.Duration;


public class ProfileController {


    @FXML
    private Button friendAction;

    @FXML
    private TextField textfield;

    @FXML
    private Text username;

    @FXML
    private VBox vbox;

    @FXML
    private VBox commentListVBOX;

    @FXML
    private AnchorPane commentPane;
    @FXML
    private ImageView x;

    private List<ProfileObserver> observers = new ArrayList<>();

    public void addObserver(ProfileObserver observer) {
        observers.add(observer);
    }

    public void removeObserver(ProfileObserver observer) {
        observers.remove(observer);
    }

    public void notifyObservers() {
        for (ProfileObserver observer : observers) {
            observer.update();
        }
    }
    private DatagramSocket socket;

    private InetAddress address;
    public ProfileController() throws SocketException, UnknownHostException {
        socket = new DatagramSocket();
        address = InetAddress.getByName("localhost");
    }
    NewsAgency newsAgency;
    ClientThreadForNews clientThreadForNews;
    @FXML
    void initialize() throws SQLException {
        username.setText(ClickedUser.getClicked());
        if(DB.statusFromMe(username.getText()).equals("request")){
            friendAction.setText("Request Sent");
        }
        else if(DB.statusFromOther(username.getText()).equals("request")){
            friendAction.setText("Accept Request");
        }
        else if(DB.statusFromMe(username.getText()).equals("accept") || DB.statusFromOther(username.getText()).equals("accept")){
            friendAction.setText("Remove Friend");
        }
        DB.loadWalls(vbox,commentPane,commentListVBOX,username.getText(),scrollPaneComment);
        newsAgency = new NewsAgency();
        clientThreadForNews = new ClientThreadForNews(socket, newsAgency);
        clientThreadForNews.start();
    }
    @FXML
    void sendComment(MouseEvent event) throws SQLException {
        DB.insertIntoComment(commentTF);

        VBox v = new VBox();
        AnchorPane anchorPane = new AnchorPane();
        anchorPane.setMinSize(360, 1);
        anchorPane.setMaxSize(360, 1);
        anchorPane.setPadding(new Insets(0,0,0,10));
        anchorPane.setStyle("-fx-background-color: black;");
        v.getChildren().add(anchorPane);
        Text username = new Text(Logged.getLoggedInUser());
        TextFlow users = new TextFlow(username);
        users.setStyle("-fx-font-size: 25; -fx-font-weight: bold;");
        users.setPadding(new Insets(0, 0, 0, 5));
        v.getChildren().add(users);
        Text texts = new Text(commentTF.getText());
        TextFlow txt = new TextFlow(texts);
        txt.setStyle("-fx-font-size: 15;");
        txt.setPadding(new Insets(0, 0, 0, 5));
        v.getChildren().add(txt);
        AnchorPane anchorPane1 = new AnchorPane();
        anchorPane1.setMinSize(360, 1);
        anchorPane1.setMaxSize(360, 1);
        anchorPane1.setStyle("-fx-background-color: black;");
        v.getChildren().add(anchorPane1);
        scrollPaneComment.setVvalue(1.0);
        Platform.runLater(() -> {
            // Allow JavaFX to perform layout and rendering
            PauseTransition pause = new PauseTransition(Duration.millis(50));
            pause.setOnFinished(e -> {
                // Scroll to the bottom of the VBox
                commentListVBOX.layout();
                scrollPaneComment.setVvalue(1.0);
            });
            pause.play();
        });
        commentListVBOX.getChildren().add(v);
        commentTF.setText("");
    }
    @FXML
    private TextField commentTF;
    @FXML
    private ScrollPane scrollPaneComment;
    @FXML
    void friends(ActionEvent event) throws IOException {
        // Behavioral Pattern: Observer
//        notifyObservers();
        Parent root = FXMLLoader.load(getClass().getResource("friends.fxml"));

        Scene newScene = new Scene(root);

        Stage stage = (Stage) ((Node)event.getSource()).getScene().getWindow();

        stage.setScene(newScene);

        stage.show();
    }

    @FXML
    void messages(ActionEvent event) throws IOException {

        Parent root = FXMLLoader.load(getClass().getResource("messages.fxml"));

        Scene newScene = new Scene(root);

        Stage stage = (Stage) ((Node)event.getSource()).getScene().getWindow();

        stage.setScene(newScene);

        stage.show();
    }

    @FXML
    void myprofile(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("myProfile.fxml"));

        Scene newScene = new Scene(root);

        Stage stage = (Stage) ((Node)event.getSource()).getScene().getWindow();

        stage.setScene(newScene);

        stage.show();
    }


    @FXML
    void news(ActionEvent event) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("news.fxml"));

        Scene newScene = new Scene(root);

        Stage stage = (Stage) ((Node)event.getSource()).getScene().getWindow();

        stage.setScene(newScene);

        stage.show();
    }
    @FXML
    void search(ActionEvent event) {
        // Your code for handling search
    }
    boolean isShowQR=false;
    private QRCodeDisplay qrCodeDisplay;
    @FXML
    private AnchorPane qr;

    @FXML
    private ImageView qrCodeImageView;
    @FXML
    void qrcode(MouseEvent event) {
        //not realize. but then realize
        // Создаем объект профиля
        Profile userProfile = new Profile();

        // Создаем объект отображения QR-кода и регистрируем его как наблюдателя
        qrCodeDisplay = new QRCodeDisplay(qrCodeImageView,username.getText());
        userProfile.addObserver(qrCodeDisplay);
        userProfile.onQRCodeClicked();
        if(!isShowQR) {
            qrCodeImageView.setVisible(true);
            qr.setVisible(true);
            isShowQR=true;
        }
        else {
            qrCodeImageView.setVisible(false);
            qr.setVisible(false);
            isShowQR=false;
        }
    }


    @FXML
    private TextField searchTextField;
    @FXML
    void searchButton(MouseEvent event) throws IOException {
        DB.search(searchTextField,event);
    }

    @FXML
    void send(MouseEvent event) throws SQLException {
        VBox v = new VBox();
        AnchorPane anchorPane=new AnchorPane();
        anchorPane.setMinSize(700,1);
        anchorPane.setMaxSize(700,1);
        anchorPane.setStyle("-fx-background-color: black;");
        v.getChildren().add(anchorPane);
        Text us = new Text(Logged.getLoggedInUser());
        TextFlow users = new TextFlow(us);
        users.setStyle("-fx-font-size: 25; -fx-font-weight: bold;");
        users.setPadding(new Insets(0,0,0,5));
        v.getChildren().add(users);
        Text texts =new Text(textfield.getText());
        TextFlow txt = new TextFlow(texts);
        txt.setStyle("-fx-font-size: 15;");
        txt.setPadding(new Insets(0,0,0,10));
        v.getChildren().add(txt);
        HBox hBox = new HBox();
        ImageView like = new ImageView(new Image("C:\\Users\\dzang\\IdeaProjects\\FinalProjectSoftware\\src\\main\\resources\\com\\example\\finalprojectsoftware\\love.png"));
        like.setFitWidth(31);
        like.setFitHeight(37);
        ImageView comment = new ImageView(new Image("C:\\Users\\dzang\\IdeaProjects\\FinalProjectSoftware\\src\\main\\resources\\com\\example\\finalprojectsoftware\\chat.png"));
        comment.setFitWidth(41);
        comment.setFitHeight(45);
        hBox.getChildren().addAll(like,comment);
        hBox.setAlignment(Pos.CENTER_LEFT);
        v.getChildren().add(hBox);
        AnchorPane anchorPane1=new AnchorPane();
        anchorPane1.setMinSize(700,1);
        anchorPane1.setMaxSize(700,1);
        anchorPane1.setStyle("-fx-background-color: black;");
        v.getChildren().add(anchorPane1);
        vbox.getChildren().add(0,v);
        like.setPickOnBounds(true);
        comment.setPickOnBounds(true);
        int ws=DB.insertIntoWalls(textfield.getText(),username.getText());
        w=ws;
        String temp = "news:"+Logged.getLoggedInUser() + ":" + textfield.getText().trim()+":"+w;
        byte[] msg = temp.getBytes(); // convert to bytes
        // create a packet & send
        DatagramPacket send = new DatagramPacket(msg, msg.length, address, Server.PORT);
        try {
            socket.send(send);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        ClientThreadForNews.setWallId(w);
        textfield.setText("");
        AtomicBoolean checkLike= new AtomicBoolean(false);
        if(checkLike.get()){
            like.setImage(new Image("C:\\Users\\dzang\\IdeaProjects\\FinalProjectSoftware\\src\\main\\resources\\com\\example\\finalprojectsoftware\\heart (1).png"));
        }
        else {
            like.setImage(new Image("C:\\Users\\dzang\\IdeaProjects\\FinalProjectSoftware\\src\\main\\resources\\com\\example\\finalprojectsoftware\\love.png"));
        }
        texts.setOnMouseClicked(eevent ->{
            System.out.println("clicked");
        });
        like.setOnMouseClicked(e->{
            System.out.println("like");
            if(!checkLike.get()){
                like.setImage(new Image("C:\\Users\\dzang\\IdeaProjects\\FinalProjectSoftware\\src\\main\\resources\\com\\example\\finalprojectsoftware\\heart (1).png"));
                checkLike.set(true);
                try {
                    DB.insertIntoLike(ws);
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
            }
            else {
                like.setImage(new Image("C:\\Users\\dzang\\IdeaProjects\\FinalProjectSoftware\\src\\main\\resources\\com\\example\\finalprojectsoftware\\love.png"));
                checkLike.set(false);
                DB.deleteFromLike(w);
            }
        });
        comment.setOnMouseClicked(e->{
            DB.setWall(w);
            DB.commentLogicAndDesign(ws,commentListVBOX);
            commentPane.setVisible(true);
            System.out.println("walling"+ws);
            int walls=wallingid;
        });
    }int w;
    int wallingid;

    @FXML
    void friendAction(ActionEvent event) {
        if(friendAction.getText().equals("Add Friend")){
            DB.addFriend(username.getText());
            friendAction.setText("Request Sent");
        }
        else if(friendAction.getText().equals("Request Sent")){
            DB.removeRequest(username.getText());
            friendAction.setText("Add Friend");
        }
        else if(friendAction.getText().equals("Remove Friend")){
            DB.cancelRequest(username.getText());
            friendAction.setText("Add Friend");
        }
        else if(friendAction.getText().equals("Accept Request")){
            DB.acceptRequest(username.getText());
            friendAction.setText("Remove Friend");
        }
    }
    @FXML
    public void friend(ActionEvent event) {

    }
    @FXML
    public void messageAction(ActionEvent event) throws IOException {
        ClickedUser.setClicked(username.getText());
        Parent root = FXMLLoader.load(getClass().getResource("messageswithuser.fxml"));

        Scene newScene = new Scene(root);

        Stage stage = (Stage) ((Node)event.getSource()).getScene().getWindow();

        stage.setScene(newScene);

        stage.show();
    }
    @FXML
    void x(MouseEvent event) {
        commentPane.setVisible(false);
    }
}
