package com.example.finalprojectsoftware;

// Behavioral Design Pattern - Observer
public interface Subject {
//    void addObserver(Observer observer);
//    void removeObserver(Observer observer);

//    void addObserver(ChatController observer);
//
//    void removeObserver(ChatController observer);
//
//    void removeObserver(MessageObserver observer);


    void addObserver(MessageObserver observer);

    void removeObserver(MessageObserver observer);

    void notifyObservers(String message);
}