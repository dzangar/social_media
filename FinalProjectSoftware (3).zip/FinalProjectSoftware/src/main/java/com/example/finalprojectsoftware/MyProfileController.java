package com.example.finalprojectsoftware;

import java.io.IOException;
import java.net.*;
import java.sql.*;
import java.util.ResourceBundle;
import java.util.concurrent.atomic.AtomicBoolean;

import javafx.animation.PauseTransition;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;
import javafx.stage.Stage;
import javafx.util.Duration;

public class MyProfileController {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private ImageView qrCodeImageView;

    @FXML
    private TextField textfield;

    @FXML
    private Text username;
    @FXML
    private AnchorPane qr;


    @FXML
    private VBox vbox;
    boolean isShowQR=false;
    private Profile userProfile = new Profile();
    private QRCodeDisplay qrCodeDisplay;
    @FXML
    private VBox commentListVBOX;
    @FXML
    private ImageView x;

    @FXML
    private AnchorPane commentPane;

    public MyProfileController() throws UnknownHostException, SocketException {
        socket = new DatagramSocket();
        address = InetAddress.getByName("localhost");
    }

    @FXML
    void x(MouseEvent event) {
        commentPane.setVisible(false);
    }

    @FXML
    void friends(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("friends.fxml"));

        Scene newScene = new Scene(root);

        Stage stage = (Stage) ((Node)event.getSource()).getScene().getWindow();

        stage.setScene(newScene);

        stage.show();
    }

    @FXML
    void messages(ActionEvent event) throws IOException {

        Parent root = FXMLLoader.load(getClass().getResource("messages.fxml"));

        Scene newScene = new Scene(root);

        Stage stage = (Stage) ((Node)event.getSource()).getScene().getWindow();

        stage.setScene(newScene);

        stage.show();
    }

    @FXML
    void myprofile(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("myProfile.fxml"));

        Scene newScene = new Scene(root);

        Stage stage = (Stage) ((Node)event.getSource()).getScene().getWindow();

        stage.setScene(newScene);

        stage.show();
    }


    @FXML
    void news(ActionEvent event) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("news.fxml"));

        Scene newScene = new Scene(root);

        Stage stage = (Stage) ((Node)event.getSource()).getScene().getWindow();

        stage.setScene(newScene);

        stage.show();
    }

    @FXML
    void qrcode(MouseEvent event) {
        // Создаем объект профиля
        Profile userProfile = new Profile();

        // Создаем объект отображения QR-кода и регистрируем его как наблюдателя
        qrCodeDisplay = new QRCodeDisplay(qrCodeImageView,username.getText());
        userProfile.addObserver(qrCodeDisplay);
        userProfile.onQRCodeClicked();
        if(!isShowQR) {
            qrCodeImageView.setVisible(true);
            qr.setVisible(true);
            isShowQR=true;
        }
        else {
            qrCodeImageView.setVisible(false);
            qr.setVisible(false);
            isShowQR=false;
        }
    }
    @FXML
    void search(ActionEvent event) {

    }


    @FXML
    void send(MouseEvent event) throws SQLException {
        VBox v = new VBox();
        AnchorPane anchorPane=new AnchorPane();
        anchorPane.setMinSize(700,1);
        anchorPane.setMaxSize(700,1);
        anchorPane.setStyle("-fx-background-color: black;");
        v.getChildren().add(anchorPane);
        Text username = new Text(Logged.getLoggedInUser());
        TextFlow users = new TextFlow(username);
        users.setStyle("-fx-font-size: 25; -fx-font-weight: bold;");
        users.setPadding(new Insets(0,0,0,5));
        v.getChildren().add(users);
        Text texts =new Text(textfield.getText());
        TextFlow txt = new TextFlow(texts);
        txt.setStyle("-fx-font-size: 15;");
        txt.setPadding(new Insets(0,0,0,10));
        v.getChildren().add(txt);
        HBox hBox = new HBox();
        ImageView like = new ImageView(new Image("C:\\Users\\dzang\\IdeaProjects\\FinalProjectSoftware\\src\\main\\resources\\com\\example\\finalprojectsoftware\\love.png"));
        like.setFitWidth(31);
        like.setFitHeight(37);
        ImageView comment = new ImageView(new Image("C:\\Users\\dzang\\IdeaProjects\\FinalProjectSoftware\\src\\main\\resources\\com\\example\\finalprojectsoftware\\chat.png"));
        comment.setFitWidth(41);
        comment.setFitHeight(45);
        hBox.getChildren().addAll(like,comment);
        hBox.setAlignment(Pos.CENTER_LEFT);
        v.getChildren().add(hBox);
        AnchorPane anchorPane1=new AnchorPane();
        anchorPane1.setMinSize(700,1);
        anchorPane1.setMaxSize(700,1);
        anchorPane1.setStyle("-fx-background-color: black;");
        v.getChildren().add(anchorPane1);
        vbox.getChildren().add(0,v);
        like.setPickOnBounds(true);
        comment.setPickOnBounds(true);
        int w=DB.insertIntoWalls(textfield.getText(),username.getText());
        String temp = "news:"+Logged.getLoggedInUser() + ":" + textfield.getText().trim()+":"+w;
        byte[] msg = temp.getBytes(); // convert to bytes
        // create a packet & send
        DatagramPacket send = new DatagramPacket(msg, msg.length, address, Server.PORT);
        try {
            socket.send(send);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        ClientThreadForNews.setWallId(w);

        textfield.setText("");
        AtomicBoolean checkLike= new AtomicBoolean(false);
        ClientThreadForNews.setWallId(w);
        if(checkLike.get()){
            like.setImage(new Image("C:\\Users\\dzang\\IdeaProjects\\FinalProjectSoftware\\src\\main\\resources\\com\\example\\finalprojectsoftware\\heart (1).png"));
        }
        else {
            like.setImage(new Image("C:\\Users\\dzang\\IdeaProjects\\FinalProjectSoftware\\src\\main\\resources\\com\\example\\finalprojectsoftware\\love.png"));
        }
        texts.setOnMouseClicked(eevent ->{
            System.out.println("clicked");
        });
        like.setOnMouseClicked(e->{
            System.out.println("like");
            if(!checkLike.get()){
                like.setImage(new Image("C:\\Users\\dzang\\IdeaProjects\\FinalProjectSoftware\\src\\main\\resources\\com\\example\\finalprojectsoftware\\heart (1).png"));
                checkLike.set(true);
                try {
                    DB.insertIntoLike(w);
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
            }
            else {
                like.setImage(new Image("C:\\Users\\dzang\\IdeaProjects\\FinalProjectSoftware\\src\\main\\resources\\com\\example\\finalprojectsoftware\\love.png"));
                checkLike.set(false);
                DB.deleteFromLike(w);
            }
        });
        comment.setOnMouseClicked(e->{
            DB.setWall(w);
            DB.commentLogicAndDesign(w,commentListVBOX);
            commentPane.setVisible(true);
            System.out.println("walling"+w);
            int walls=wallingid;
        });
    }
    private DatagramSocket socket;

    private InetAddress address;

    NewsAgency newsAgency;
    ClientThreadForNews clientThreadForNews;
    @FXML
    void initialize() throws SQLException {
        username.setText(Logged.getLoggedInUser());
        DB.loadWalls(vbox, commentPane, commentListVBOX, Logged.getLoggedInUser(), scrollPaneComment);
        newsAgency = new NewsAgency();
        clientThreadForNews = new ClientThreadForNews(socket, newsAgency);
        clientThreadForNews.start();
    }

    static int wallingid;

    int walls;
    @FXML
    private TextField commentTF;

    @FXML
    private ScrollPane scrollPaneComment;
    @FXML
    void sendComment(MouseEvent event) throws SQLException {
        System.out.println("walls" +walls);
        DB.insertIntoComment(commentTF);
        VBox v = new VBox();
        AnchorPane anchorPane = new AnchorPane();
        anchorPane.setMinSize(360, 1);
        anchorPane.setMaxSize(360, 1);
        anchorPane.setPadding(new Insets(0,0,0,10));
        anchorPane.setStyle("-fx-background-color: black;");
        v.getChildren().add(anchorPane);
        Text username = new Text(Logged.getLoggedInUser());
        TextFlow users = new TextFlow(username);
        users.setStyle("-fx-font-size: 25; -fx-font-weight: bold;");
        users.setPadding(new Insets(0, 0, 0, 5));
        v.getChildren().add(users);
        Text texts = new Text(commentTF.getText());
        TextFlow txt = new TextFlow(texts);
        txt.setStyle("-fx-font-size: 15;");
        txt.setPadding(new Insets(0, 0, 0, 5));
        v.getChildren().add(txt);
        AnchorPane anchorPane1 = new AnchorPane();
        anchorPane1.setMinSize(360, 1);
        anchorPane1.setMaxSize(360, 1);
        anchorPane1.setStyle("-fx-background-color: black;");
        v.getChildren().add(anchorPane1);
        scrollPaneComment.setVvalue(1.0);
        Platform.runLater(() -> {
            // Allow JavaFX to perform layout and rendering
            PauseTransition pause = new PauseTransition(Duration.millis(50));
            pause.setOnFinished(e -> {
                // Scroll to the bottom of the VBox
                commentListVBOX.layout();
                scrollPaneComment.setVvalue(1.0);
            });
            pause.play();
        });
        commentListVBOX.getChildren().add(v);
        commentTF.setText("");
    }
    @FXML
    private TextField searchTextField;
    @FXML
    void searchButton(MouseEvent event) throws IOException {
        DB.search(searchTextField,event);
    }
}
